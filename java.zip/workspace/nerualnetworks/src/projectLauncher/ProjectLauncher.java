package projectLauncher;
import flappyBird.FlappyEvolution;
import nerualMnist.NerualMnist;
import apcs.Window;
public class ProjectLauncher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}
	public static void flappyEvolution() {
		
	}

}
